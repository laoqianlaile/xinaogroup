#pragma once
#include "stdafx.h"
VOID SendXmlMessage(HWND Dlg, PWCHAR wxid, PWCHAR fWxid, PWCHAR title, PWCHAR content, PWCHAR pic);
VOID SendXmlCard(HWND Dlg, PWCHAR wxid, PWCHAR fWxid, PWCHAR name);