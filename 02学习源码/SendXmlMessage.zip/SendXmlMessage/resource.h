//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� SendXmlMessage.rc ʹ��
//
#define MAIN                            101
#define WXID                            1001
#define TITLE                           1002
#define CONTENT                         1003
#define PIC                             1004
#define XML_LOG                         1005
#define SEND_XML                        1006
#define SEND_XML2                       1007
#define NEW_SEND_XML                    1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
