﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 WeChatRobot.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WECHATROBOT_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDD_MAIN                        131
#define IDD_FRIEND_LIST                 133
#define IDD_CHAT_RECORDS                135
#define IDD_FUNCTIONS                   137
#define IDR_MENU1                       141
#define IDR_MENU2                       142
#define IDD_SendMsg                     143
#define IDI_ICON2                       145
#define IDD_INFORMATION                 146
#define IDD_ROOMANNOUNCE                148
#define IDD_DECRYPT_IMAGE               150
#define IDD_ADD_MEMBER                  152
#define IDD_SEND_ROOM_MSG               154
#define IDD_SendCard                    156
#define IDD_CHATROOM_MEMBER             158
#define IDD_PAY                         162
#define IDB_BITMAP1                     166
#define IDD_ABOUT_AUTHOR                167
#define IDD_ADD_USER                    169
#define IDD_SET_ROOM_NAME               171
#define IDD_SENDAT                      173
#define IDD_OpenUrl                     175
#define IDC_INJECT_DLL                  1000
#define IDC_UNLOAD_DLL                  1001
#define IDC_SHOW_QRPIC                  1003
#define IDC_QRPIC                       1004
#define IDC_TAB1                        1005
#define IDC_FRIENDLIST                  1006
#define IDC_LIST1                       1007
#define IDC_RADIO1                      1008
#define IDC_RADIO2                      1009
#define IDC_RADIO3                      1010
#define IDC_EDIT1                       1011
#define IDC_Send                        1012
#define IDC_EDIT2                       1012
#define IDC_INFORMATION                 1013
#define IDC_ACCOUNT                     1013
#define IDC_DECRYPT_PIC                 1014
#define IDC_NICKNAME                    1014
#define IDC_EDIT3                       1014
#define IDC_PHONE                       1015
#define IDC_EDIT4                       1015
#define IDC_DEVICE                      1016
#define IDC_EDIT5                       1016
#define IDC_PROVINCE                    1017
#define IDC_CITY                        1018
#define IDC_HEADER                      1019
#define IDC_NATION                      1020
#define IDC_WXID                        1021
#define IDC_SEX                         1022
#define IDC_SendRoomAnnouncement        1024
#define IDC_DecryptImage                1025
#define IDC_MAKE_SURE                   1026
#define IDC_ChatRoomWXID                1027
#define IDC_SendChatRoomMsg             1029
#define IDC_SendCard                    1030
#define IDC_MULTI_OPEN                  1031
#define IDC_DECRYPT_DB                  1032
#define IDC_ADD_USER                    1033
#define IDC_AUTO_CHAT                   1034
#define IDC_GET_EXPRESSION              1035
#define IDC_SetRoomName                 1036
#define IDC_OPEN_URL                    1036
#define IDC_SendAt                      1037
#define IDC_OPEN                        1038
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_32796                        32796
#define ID_32797                        32797
#define ID_32798                        32798

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        177
#define _APS_NEXT_COMMAND_VALUE         32799
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
