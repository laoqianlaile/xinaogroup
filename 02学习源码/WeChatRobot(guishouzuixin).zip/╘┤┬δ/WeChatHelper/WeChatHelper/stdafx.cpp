#include "stdafx.h"
#include "message.h"
