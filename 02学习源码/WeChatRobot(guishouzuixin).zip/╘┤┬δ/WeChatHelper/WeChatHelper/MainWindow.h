#pragma once
#include "stdafx.h"

void LogoutWeChat();